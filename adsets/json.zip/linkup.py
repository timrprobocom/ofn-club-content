from __future__ import print_function
import glob
import os

for fn in glob.glob('*.json'):
    if fn == 'all.json':
	continue
    json = eval( open(fn).read())
    base,_ = os.path.splitext(fn)
    match = None
    for ext in ('.JPEG','.JPG','.jpeg','.jpg','.png','.pdf'):
	if os.path.exists( '../'+base+ext ):
	    match = base+ext
	    break
    if not match:
	print( "NO MATCH for", base )
	continue

    for yr,v in json.items():
	if not isinstance(v[0],int):
	    v = [int(k) for k in v]
	for mo in v:
	    name = '../%s-%02d/%s' % (yr, mo, match )
	    if not os.path.exists( name) :
		print( "FAILED", name )
		print( "os.symlink(", '../'+match, name )
		os.symlink( '../'+match, name )



